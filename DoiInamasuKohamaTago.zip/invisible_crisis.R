
# packages ----------------------------------------------------------------


library(tidyverse)
library(lubridate)
library(BalanceR)
library(fastDummies)
library(cem)
library(ebal)
library(CBPS)
library(broom)
library(purrr)
library(rdd)

theme_set(theme_minimal())

# importing data --------------------------------------------------------------------


cutoff <- "2018-12-28 18:00:00"

df <- read_csv("data/data_combined.csv", guess_max = 6000) %>% 
  mutate_at(vars(matches("(jpn|rok|policy)")), na_if, 6) %>% 
  mutate_at(vars(matches("(np_[0-9]+|tv_[ABCD]_[0-9]+|web_[0-9]+)")), replace_na, 0) %>% 
  mutate_at(vars(contains("time")), ymd_hms, tz = "Asia/Tokyo") %>% 
  mutate(treatment = treatment %>% 
           replace_na(0),
         gender = gender %>% 
           na_if(2),
         ideology = ideology %>% 
           na_if(12),
         use_of_force = use_of_force %>% 
           na_if(5),
         hawk_dove = hawk_dove %>% 
           na_if(3),
         know_event = know_event %>% 
           na_if(3),
         party = party %>% 
           na_if(9),
         critical = (critical_1 - critical_2 + critical_3 + critical_4 + critical_6 - 
                       critical_7 + critical_8 + critical_9 + critical_10 + critical_11 + 
                       critical_12),
         sdo = sdo_1 + sdo_2 + sdo_3 + sdo_4 + sdo_5 + sdo_6 + sdo_7 + sdo_8 + (7 - sdo_9) + 
           (7 - sdo_10) + (7 - sdo_11) + (7 - sdo_12) + (7 - sdo_13) + (7 - sdo_14) + (7 - sdo_15) + 
           (7 - sdo_16),
         t_ideology = case_when(ideology < 6 ~ 0,
                                ideology == 6 ~ 1,
                                ideology > 6 ~ 2,
                                ideology == 12 ~ NA_real_),
         t_sdo = case_when(sdo < quantile(sdo, 1/3, na.rm = TRUE) ~ 0,
                           sdo >= quantile(sdo, 1/3, na.rm = TRUE) & 
                             sdo <= quantile(sdo, 2/3, na.rm = TRUE) ~ 1,
                           sdo > quantile(sdo, 2/3, na.rm = TRUE) ~ 2,
                           TRUE ~ NA_real_),
         treatment = case_when(wave == 1 & time_start < ymd_hms(cutoff, tz = "Asia/Tokyo") ~ 0,
                               wave == 1 & time_start > ymd_hms(cutoff, tz = "Asia/Tokyo") ~ 1,
                               TRUE ~ treatment),
         time = interval(ymd_hms(cutoff, tz = "Asia/Tokyo"), time_start) %>% 
           time_length(unit = "day"),
         jpn_gov_3 = if_else(wave != 1, 6 - jpn_gov_3, jpn_gov_3),
         rok_gov_3 = if_else(wave != 1, 6 - rok_gov_3, rok_gov_3)) %>% 
  filter(agree == 1)

event <- tibble(date_time = c(ymd_hms("2018-12-28 18:00:00", tz = "Asia/Tokyo"),
                              ymd_hms("2019-01-04 18:00:00", tz = "Asia/Tokyo"),
                              ymd_hms("2019-01-08 18:00:00", tz = "Asia/Tokyo"),
                              ymd_hms("2019-01-21 18:00:00", tz = "Asia/Tokyo")),
                event = c("Movie (J)", "Movie (K)", "Quarrels", "Final Opinion (J)") %>% 
                  fct_inorder())

google <- read_csv("data/google_trends.csv") %>% 
  dplyr::select(-isPartial) %>% 
  gather(key = term, value = interests, -date) %>% 
  mutate(date = ymd_hms(date) %>% 
           with_tz("Asia/Tokyo"))

# time trend --------------------------------------------------------------


df %>% 
  count(wave, treatment)

df %>% 
  count(wave, know_event)

df %>% 
  filter((wave == 1 & date(time_start) > "2018-12-26" & date(time_start) < "2018-12-30") | 
           (wave == 2 & date(time_start) > "2019-01-15")) %>% 
  mutate(date_time = round_date(time_start, "15 mins")) %>% 
  count(wave, treatment, date_time) %>% 
  ggplot() + 
  geom_line(aes(x = date_time, y = n, colour = as.factor(treatment))) + 
  geom_vline(aes(xintercept = date_time, linetype = event), data = event) + 
  facet_wrap(~ wave, scales = "free") + 
  theme(legend.position = "bottom") + 
  labs(x = "Date", y = "No of respondents", linetype = "", colour = "")
ggsave("figures/ts_respondents.png")

google %>% 
  ggplot() + 
  geom_line(aes(x = date, y = interests)) + 
  geom_rug(aes(x = time_start), data = df) + 
  geom_vline(aes(xintercept = date_time), linetype = 2, data = event) + 
  geom_text(aes(x = date_time, y = 105, label = event), hjust = -0.1, data = event) + 
  theme(legend.position = "bottom") + 
  scale_x_datetime(limits = c(min(google$date), max(google$date) + days(5))) + 
  labs(x = "Date", y = "No of search", linetype = "")
ggsave("figures/ts_gtrend.png")


# weighting ----------------------------------------------------------------

cem_weight <- function(data) {
  
  mat <- data %>%
    dplyr::select(treatment, gender, age, educ, region, t_ideology, t_sdo) %>%
    cem(data = ., treatment = "treatment", baseline.group = "3",
        cutpoints = list(gender = seq(-0.5, 1.5, by = 1),
                         age = seq(9.5, 79.5, by = 10),
                         educ = seq(0.5, 7.5, by = 1),
                         region = seq(0.5, 6.5, by = 1),
                         t_ideology = seq(-0.5, 2.5, by = 1),
                         t_sdo = seq(-0.5, 2.5, by = 1)))
  
  data %>%
    mutate(cem_w = mat$w) %>%
    return()
  
}

ebal_weight <- function(data){
  
  temp <- data %>% 
    dplyr::select(gender, generation, educ, region, t_ideology, t_sdo) %>% 
    dummy_cols(c("generation", "educ", "region", "t_ideology", "t_sdo"), remove_first_dummy = TRUE) %>% 
    dplyr::select(-generation, -educ, -region, -t_ideology, -t_sdo)
  
  temp_t <- temp[data$treatment == 0,] %>% 
    as.matrix()
  
  ebal_w <- rep(1, nrow(temp_t))
  
  for (i in 1:3) {
    temp_c <- temp[data$treatment == i,] %>% 
      as.matrix()
    
    temp_ebal <- ebalance(c(rep(0, nrow(temp_c)), rep(1, nrow(temp_t))), rbind(temp_c, temp_t))
    
    ebal_w <- c(ebal_w, temp_ebal$w)
  }
  
  data %>% 
    mutate(ebal_w) %>% 
    return()
}

cbps_weight <- function(data){
  
  fit <- CBPS(as.factor(treatment) ~ 
                gender + age + as.factor(educ) + as.factor(region) + as.factor(t_ideology) + as.factor(t_sdo), 
              data = data)
  
  if (fit$converged != 0) message("the model does not converge.")
  
  data %>% 
    mutate(cbps_w = fit$weights) %>% 
    return()
  
}

df1 <- df %>% 
  drop_na(gender, age, educ, region, ideology, sdo) %>% 
  filter((wave == 1 & date(time_start) > "2018-12-26" & date(time_start) < "2018-12-30") | 
           (wave == 2 & date(time_start) > "2019-01-15") | 
           wave == 3) %>% 
  filter(between(age, 20, 69)) %>% 
  mutate(treatment = case_when(wave == 1 & treatment == 0 ~ 0,
                               wave == 1 & treatment == 1 ~ 1,
                               wave == 2 ~ 2,
                               wave == 3 ~ 3),
         generation = age %/% 10 * 10) %>% 
  cem_weight() %>% 
  ebal_weight() %>% 
  cbps_weight()

df1 %>% 
  count(wave, treatment)

df1 %>% 
  drop_na(wave, age, gender, educ, region, ideology, sdo) %>% 
  dummy_cols(c("educ", "region")) %>% 
  BalanceR(group = "wave", 
           cov = c("age", "gender", str_c("educ_", 1:7), str_c("region_", 1:6), "ideology", "sdo")) %>% 
  plot(color = FALSE) + 
  scale_y_discrete(label = c("SDO", "Ideology", "Kyushu/Okinawa", "Chugoku/Shikoku", 
                             "Kinki", "Chubu", "Kanto", "Hokkaido/Tohoku", "MA/Ph.D", 
                             "Graduate student", "College graduate", "College student", 
                             "High school graduate", "High school student", 
                             "Less than High school", "Gender", "Age"))
ggsave("figures/balance_covariates.png")

df1 %>% 
  filter(cem_w > 0) %>% 
  nrow()

df1 %>% 
  filter(ebal_w > 0) %>% 
  nrow()

df1 %>% 
  filter(cbps_w > 0) %>% 
  nrow()

df1 %>% 
  ggplot() + 
  geom_point(aes(x = cem_w, y = ebal_w))

df1 %>% 
  ggplot() + 
  geom_point(aes(x = ebal_w, y = cbps_w))

df1 %>% 
  ggplot() + 
  geom_point(aes(x = cbps_w, y = cem_w))

bal_hist <- function(data, weights, covar, moderator = NULL) {
  
  if (is_null(moderator)) {
    
    data %>% 
      rename(weights = weights, covar = covar) %>% 
      group_by(treatment, covar) %>% 
      summarise(n = sum(weights)) %>% 
      group_by(treatment) %>% 
      mutate(n = n/sum(n)) %>% 
      ggplot() + 
      geom_bar(aes(x = covar, y = n, fill = as.factor(treatment)), 
               stat = "identity", position = "dodge", show.legend = FALSE) + 
      labs(x = covar)
    
  } else {
    
    data %>% 
      rename(weights = weights, covar = covar, moderator = moderator) %>% 
      group_by(treatment, covar, moderator) %>% 
      summarise(n = sum(weights)) %>% 
      group_by(treatment, moderator) %>% 
      mutate(n = n/sum(n)) %>% 
      ggplot() + 
      geom_bar(aes(x = covar, y = n, fill = as.factor(treatment)), 
               stat = "identity", position = "dodge", show.legend = FALSE) + 
      facet_wrap(~moderator) + 
      labs(x = covar, title = moderator)
    
  }
  
}

bal_hist(df1, "ebal_w", "gender")
bal_hist(df1, "ebal_w", "gender", "t_ideology")


# analysis ----------------------------------------------------------------

sim_df <- function(data){
  tibble(wave = data$wave,
         treatment = data$treatment,
         time_start = data$time_start) %>% 
    return()
}

n <- 1

for (i in c("cem", "ebal", "cbps")) {
  
  df1 %>% 
    rename(weights = str_glue("{i}_w")) %>% 
    dplyr::select(treatment, wave, time_start, ideology, sdo, use_of_force, hawk_dove, weights) %>% 
    gather(key = type, value = response, ideology, sdo, use_of_force, hawk_dove) %>% 
    group_by(type) %>% 
    nest() %>% 
    mutate(result = purrr::map(data, 
                               ~lm(response ~ as.factor(treatment), weights = weights, data = .) %>% 
                                 tidy(conf.int = TRUE))) %>% 
    dplyr::select(type, result) %>% 
    unnest() %>% 
    ungroup() %>% 
    filter(str_detect(term, "treatment")) %>% 
    mutate(type = type %>% 
             fct_inorder(),
           term = term %>% 
             str_remove("as.factor[(]treatment[)]"),
           signif = if_else(p.value < 0.05, "<0.05", ">0.05")) %>% 
    ggplot() + 
    geom_pointrange(aes(x = as.factor(term), y = estimate, ymin = conf.low, ymax = conf.high, 
                        linetype = signif),
                    position = position_dodge(width = 1)) + 
    geom_hline(aes(yintercept = 0), alpha = 0.3) + 
    facet_wrap(~ type, scales = "free_y") + 
    theme(legend.position = "bottom") + 
    labs(x = "", y = "", title = i)
  ggsave(str_glue("figures/attitude/treatment_attitude_{i}.png"))
  
  df1 %>% 
    rename(weights = str_glue("{i}_w")) %>% 
    filter(wave == 1) %>% 
    mutate(time_start = interval(ymd_hms("2018-12-28 18:00:00", tz = "Asia/Tokyo"),
                                 time_start) %>% 
             time_length("day")) %>% 
    dplyr::select(treatment, wave, time_start, ideology, sdo, use_of_force, hawk_dove, weights) %>% 
    gather(key = type, value = response, ideology, sdo, use_of_force, hawk_dove) %>% 
    group_by(type) %>% 
    nest() %>% 
    mutate(result = data %>% 
             purrr::map(~lm(response ~ as.factor(treatment)*poly(time_start, n, raw = TRUE), weights = weights, data = .)),
           data = data %>% 
             purrr::map(sim_df),
           pred = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,1]),
           conf_low = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,2]),
           conf_high = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,3])) %>% 
    dplyr::select(-result) %>% 
    unnest() %>% 
    ggplot() + 
    geom_line(aes(x = time_start, y = pred, group = as.factor(treatment))) + 
    geom_ribbon(aes(x = time_start, ymin = conf_low, ymax = conf_high, group = as.factor(treatment)),
                alpha = 0.5) + 
    geom_vline(aes(xintercept = 0)) + 
    geom_rug(aes(x = time_start)) + 
    facet_wrap(~ type, scale = "free_y") + 
    labs(x = "", y = "", title = i)
  ggsave(str_glue("figures/attitude/ts_treatment_attitude_{i}.png"))
  
}

df1 %>% 
  pivot_longer(contains("fact"), names_to = "type", values_to = "response") %>% 
  mutate(response = if_else(response == 3, 0, 1)) %>% 
  group_by(type) %>% 
  nest() %>% 
  mutate(result = map(data, ~lm(response ~ as.factor(treatment) + gender + age + ideology + 
                                  as.factor(educ) + as.factor(region),
                                data = .) %>% 
                        tidy(conf.int = TRUE))) %>% 
  unnest(result) %>% 
  filter(str_detect(term, "treatment")) %>% 
  mutate(type = type %>% 
           str_replace("f", "F") %>% 
           str_replace("_", " ") %>% 
           factor(levels = str_c("Fact ", 1:11)),
         term = term %>% 
           str_remove("as.factor[(]treatment[)]"),
         signif = if_else(p.value < 0.05, "<0.05", ">0.05")) %>% 
  ggplot(aes(x = term, y = estimate, ymin = conf.low, ymax = conf.high,
             linetype = signif)) + 
  geom_pointrange() + 
  geom_hline(yintercept = 0, alpha = 0.5) + 
  facet_wrap(~ type, scales = "free") + 
  theme(legend.position = "bottom") + 
  labs(x = "Treatment", y = "ATE", linetype = "P-value")
ggsave("figures/fact/treatment_fact_ols.png")

for (i in c("cem", "ebal", "cbps")) {
  
  df1 %>% 
    rename(weights = str_glue("{i}_w")) %>% 
    gather(key = type, value = response, contains("fact")) %>% 
    mutate(response = if_else(response == 3, 0, 1)) %>% 
    group_by(type) %>% 
    nest() %>% 
    mutate(result = purrr::map(data, 
                               ~lm(response ~ as.factor(treatment), weights = weights, data = .) %>% 
                                 tidy(conf.int = TRUE))) %>% 
    dplyr::select(type, result) %>% 
    unnest() %>% 
    filter(str_detect(term, "treatment")) %>% 
    mutate(type = type %>% 
             str_replace("f", "F") %>% 
             str_replace("_", " ") %>% 
             factor(levels = str_c("Fact ", 1:11)),
           term = term %>% 
             str_remove("as.factor[(]treatment[)]"),
           signif = if_else(p.value < 0.05, "<0.05", ">0.05")) %>% 
    ggplot() + 
    geom_pointrange(aes(x = as.factor(term), y = estimate, ymin = conf.low, ymax = conf.high, 
                        linetype = signif)) + 
    geom_hline(aes(yintercept = 0), alpha = 0.3) + 
    facet_wrap(~ type, scales = "free_y") + 
    theme(legend.position = "bottom") + 
    labs(x = "", y = "", linetype = "P-value", title = str_to_upper(i))
  ggsave(str_glue("figures/fact/treatment_fact_{i}.png"))
  
  df1 %>% 
    rename(weights = str_glue("{i}_w")) %>% 
    filter(wave == 1) %>% 
    mutate(time_start = interval(ymd_hms("2018-12-28 18:00:00", tz = "Asia/Tokyo"),
                                 time_start) %>% 
             time_length("day")) %>% 
    gather(key = type, value = response, contains("fact")) %>% 
    mutate(response = if_else(response == 3, 0, 1)) %>% 
    group_by(type) %>% 
    nest() %>% 
    mutate(result = data %>% 
             purrr::map(~lm(response ~ as.factor(treatment)*poly(time_start, n, raw = TRUE), weights = weights, data = .)),
           data = data %>% 
             purrr::map(sim_df),
           pred = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,1]),
           conf_low = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,2]),
           conf_high = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,3])) %>% 
    dplyr::select(-result) %>% 
    unnest() %>% 
    ggplot() + 
    geom_line(aes(x = time_start, y = pred, group = as.factor(treatment))) + 
    geom_ribbon(aes(x = time_start, ymin = conf_low, ymax = conf_high, group = as.factor(treatment)),
                alpha = 0.5) + 
    geom_vline(aes(xintercept = 0)) + 
    geom_rug(aes(x = time_start)) + 
    facet_wrap(~ type, scale = "free_y") + 
    labs(x = "", y = "", title = i)
  ggsave(str_glue("figures/fact/ts_treatment_fact_{i}.png"))
  
}

df1 %>% 
  pivot_longer(contains("policy"), names_to = "type", values_to = "response") %>% 
  mutate(response = if_else(response == 3, 0, 1)) %>% 
  group_by(type) %>% 
  nest() %>% 
  mutate(result = map(data, 
                      ~lm(response ~ as.factor(treatment), data = .) %>% 
                        tidy(conf.int = TRUE))) %>% 
  unnest(result) %>% 
  filter(str_detect(term, "treatment")) %>% 
  mutate(type = type %>% 
           str_replace("p", "P") %>% 
           str_replace("_", " "),
         term = term %>% 
           str_remove("as.factor[(]treatment[)]"),
         signif = if_else(p.value < 0.05, "<0.05", ">0.05")) %>% 
  ggplot() + 
  geom_pointrange(aes(x = as.factor(term), y = estimate, ymin = conf.low, ymax = conf.high, 
                      linetype = signif),
                  position = position_dodge(width = 1)) + 
  geom_hline(aes(yintercept = 0), alpha = 0.3) + 
  facet_wrap(~ type, scales = "free_y") + 
  theme(legend.position = "bottom") + 
  labs(x = "Treatment", y = "ATE", linetype = "P-value")
ggsave("figures/policy/treatment_policy_ols.png")

for (i in c("cem", "ebal", "cbps")) {
  
  df1 %>% 
    rename(weights = str_glue("{i}_w")) %>% 
    gather(key = type, value = response, contains("policy")) %>% 
    mutate(response = if_else(response == 3, 0, 1)) %>% 
    group_by(type) %>% 
    nest() %>% 
    mutate(result = purrr::map(data, 
                               ~lm(response ~ as.factor(treatment), weights = weights, data = .) %>% 
                                 tidy(conf.int = TRUE))) %>% 
    dplyr::select(type, result) %>% 
    unnest() %>% 
    filter(str_detect(term, "treatment")) %>% 
    mutate(type = type %>% 
             str_replace("p", "P") %>% 
             str_replace("_", " "),
           term = term %>% 
             str_remove("as.factor[(]treatment[)]"),
           signif = if_else(p.value < 0.05, "<0.05", ">0.05")) %>% 
    ggplot() + 
    geom_pointrange(aes(x = as.factor(term), y = estimate, ymin = conf.low, ymax = conf.high, 
                        linetype = signif),
                    position = position_dodge(width = 1)) + 
    geom_hline(aes(yintercept = 0), alpha = 0.3) + 
    facet_wrap(~ type, scales = "free_y") + 
    theme(legend.position = "bottom") + 
    labs(x = "", y = "", linetype = "P-value", title = str_to_upper(i))
  ggsave(str_glue("figures/policy/treatment_policy_{i}.png"))
  
  df1 %>% 
    rename(weights = str_glue("{i}_w")) %>% 
    filter(wave == 1) %>% 
    mutate(time_start = interval(ymd_hms("2018-12-28 18:00:00", tz = "Asia/Tokyo"),
                                 time_start) %>% 
             time_length("day")) %>% 
    gather(key = type, value = response, contains("policy")) %>% 
    mutate(response = if_else(response == 3, 0, 1)) %>% 
    group_by(type) %>% 
    nest() %>% 
    mutate(result = data %>% 
             purrr::map(~lm(response ~ as.factor(treatment)*poly(time_start, n, raw = TRUE), weights = weights, data = .)),
           data = data %>% 
             purrr::map(sim_df),
           pred = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,1]),
           conf_low = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,2]),
           conf_high = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,3])) %>% 
    dplyr::select(-result) %>% 
    unnest() %>% 
    ggplot() + 
    geom_line(aes(x = time_start, y = pred, group = as.factor(treatment))) + 
    geom_ribbon(aes(x = time_start, ymin = conf_low, ymax = conf_high, group = as.factor(treatment)),
                alpha = 0.5) + 
    geom_vline(aes(xintercept = 0)) + 
    geom_rug(aes(x = time_start)) + 
    facet_wrap(~ type, scale = "free_y") + 
    labs(x = "", y = "", title = i)
  ggsave(str_glue("figures/policy/ts_treatment_policy_{i}.png"))
  
}

df1 %>% 
  pivot_longer(contains("gov"), names_to = "type", values_to = "response") %>% 
  group_by(type) %>% 
  nest() %>% 
  mutate(result = purrr::map(data, 
                             ~lm(response ~ as.factor(treatment), data = .) %>% 
                               tidy(conf.int = TRUE))) %>% 
  unnest(result) %>% 
  filter(str_detect(term, "treatment")) %>% 
  mutate(type = type %>% 
           str_replace("_gov_", " ") %>% 
           str_to_upper(),
         term = term %>% 
           str_remove("as.factor[(]treatment[)]"),
         signif = if_else(p.value < 0.05, "<0.05", ">0.05")) %>% 
  ggplot() + 
  geom_pointrange(aes(x = as.factor(term), y = estimate, ymin = conf.low, ymax = conf.high, 
                      linetype = signif),
                  position = position_dodge(width = 0.5)) + 
  geom_hline(aes(yintercept = 0), alpha = 0.3) + 
  facet_wrap(~ type, scales = "free_y", nrow = 2) + 
  theme(legend.position = "bottom") + 
  labs(x = "", y = "", linetype = "P-value")
ggsave("figures/treatment_effects/treatment_effects_ols.png")

for (i in c("cem", "ebal", "cbps")) {
  
  df1 %>% 
    rename(weights = str_glue("{i}_w")) %>% 
    gather(key = type, value = response, contains("gov")) %>% 
    group_by(type) %>% 
    nest() %>% 
    mutate(result = purrr::map(data, 
                               ~lm(response ~ as.factor(treatment), weights = weights, data = .) %>% 
                                 tidy(conf.int = TRUE))) %>% 
    dplyr::select(type, result) %>% 
    unnest() %>% 
    filter(str_detect(term, "treatment")) %>% 
    mutate(type = type %>% 
             str_replace("_gov_", " ") %>% 
             str_to_upper(),
           term = term %>% 
             str_remove("as.factor[(]treatment[)]"),
           signif = if_else(p.value < 0.05, "<0.05", ">0.05")) %>% 
    ggplot() + 
    geom_pointrange(aes(x = as.factor(term), y = estimate, ymin = conf.low, ymax = conf.high, 
                        linetype = signif),
                    position = position_dodge(width = 0.5)) + 
    geom_hline(aes(yintercept = 0), alpha = 0.3) + 
    facet_wrap(~ type, scales = "free_y", nrow = 2) + 
    theme(legend.position = "bottom") + 
    labs(x = "", y = "", linetype = "P-value", title = str_to_upper(i))
  ggsave(str_glue("figures/treatment_effects/treatment_effects_{i}.png"))
  
  df1 %>% 
    rename(weights = str_glue("{i}_w")) %>% 
    filter(wave == 1) %>% 
    mutate(time_start = interval(ymd_hms("2018-12-28 18:00:00", tz = "Asia/Tokyo"),
                                 time_start) %>% 
             time_length("day")) %>% 
    gather(key = type, value = response, contains("gov")) %>% 
    group_by(type) %>% 
    nest() %>% 
    mutate(result = data %>% 
             purrr::map(~lm(response ~ as.factor(treatment)*poly(time_start, n, raw = TRUE), weights = weights, data = .)),
           data = data %>% 
             purrr::map(sim_df),
           pred = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,1]),
           conf_low = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,2]),
           conf_high = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,3])) %>% 
    dplyr::select(-result) %>% 
    unnest() %>% 
    mutate(state = str_extract(type, "(jpn|rok)"),
           type = str_extract(type, "gov_[0-9]+")) %>% 
    ggplot() + 
    geom_line(aes(x = time_start, y = pred, group = as.factor(treatment))) + 
    geom_ribbon(aes(x = time_start, ymin = conf_low, ymax = conf_high, group = as.factor(treatment)),
                alpha = 0.5) + 
    geom_vline(aes(xintercept = 0)) + 
    geom_rug(aes(x = time_start)) + 
    facet_grid(state ~ type, scale = "free_y") + 
    labs(x = "", y = "", title = i)
  ggsave(str_glue("figures/treatment_effects/ts_treatment_effects_{i}.png"))
  
}

df1 %>%
  rename(weights = ebal_w) %>%
  mutate(group = t_ideology) %>%
  drop_na(group) %>%
  gather(key = type, value = response, contains("gov")) %>%
  group_by(type, group) %>%
  nest() %>%
  mutate(result = purrr::map(data,
                      ~lm(response ~ as.factor(treatment), weights = weights, data = .) %>%
                        tidy(conf.int = TRUE))) %>%
  dplyr::select(-data) %>%
  unnest() %>%
  filter(str_detect(term, "treatment")) %>%
  mutate(type = type %>%
           fct_inorder(),
         term = term %>%
           str_remove("as.factor[(]treatment[)]"),
         signif = if_else(p.value < 0.05, "<0.05", ">0.05")) %>%
  ggplot() +
  geom_pointrange(aes(x = as.factor(term), y = estimate, ymin = conf.low, ymax = conf.high,
                      colour = as.factor(group), linetype = signif),
                  position = position_dodge(width = 0.5)) +
  geom_hline(aes(yintercept = 0), alpha = 0.3) +
  facet_wrap(~ type, scales = "free_y", nrow = 2) +
  theme(legend.position = "bottom") +
  labs(x = "", y = "treatment")
ggsave("figures/doi/ideology/treatment_effect_ideology.png")

results <- df1 %>%
  rename(weights = ebal_w) %>%
  mutate(group = t_ideology) %>%
  drop_na(group) %>%
  gather(key = type, value = response, contains("gov")) %>%
  group_by(type, group) %>%
  nest() %>%
  mutate(result = data %>%
           purrr::map(~lm(response ~ as.factor(treatment)*time_start, weights = weights, data = .)),
         data = data %>%
           purrr::map(sim_df),
         pred = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,1]),
         conf_low = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,2]),
         conf_high = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,3]),
         result = result %>%
           purrr::map(tidy))

for (i in unique(results$type)) {
  results %>%
    dplyr::select(-result) %>%
    unnest() %>%
    filter(type == i) %>%
    ggplot() +
    geom_line(aes(x = time_start, y = pred, group = as.factor(treatment))) +
    geom_ribbon(aes(x = time_start, ymin = conf_low, ymax = conf_high, group = as.factor(treatment)),
                alpha = 0.5) +
    geom_vline(aes(xintercept = ymd_hms("2018-12-28 18:00:00", tz = "Asia/Tokyo"))) +
    geom_rug(aes(x = time_start)) +
    facet_grid(~group) +
    labs(title = i)
  ggsave(str_glue("figures/doi/ideology/{i}_ideology.png"))
}

# df1 %>% 
#   rename(weights = ebal_w) %>% 
#   mutate(group = t_sdo) %>% 
#   drop_na(group) %>% 
#   gather(key = type, value = response, contains("gov")) %>% 
#   group_by(type, group) %>% 
#   nest() %>% 
#   mutate(result = purrr::map(data, 
#                       ~lm(response ~ as.factor(treatment), weights = weights, data = .) %>% 
#                         tidy(conf.int = TRUE))) %>% 
#   dplyr::select(-data) %>% 
#   unnest() %>% 
#   filter(str_detect(term, "treatment")) %>% 
#   mutate(type = type %>% 
#            fct_inorder(),
#          term = term %>% 
#            str_remove("as.factor[(]treatment[)]"),
#          signif = if_else(p.value < 0.05, "<0.05", ">0.05")) %>% 
#   ggplot() + 
#   geom_pointrange(aes(x = as.factor(term), y = estimate, ymin = conf.low, ymax = conf.high, 
#                       colour = as.factor(group), linetype = signif),
#                   position = position_dodge(width = 0.5)) + 
#   geom_hline(aes(yintercept = 0), alpha = 0.3) + 
#   facet_wrap(~ type, scales = "free_y", nrow = 2) + 
#   theme(legend.position = "bottom") + 
#   labs(x = "", y = "treatment")
# ggsave("figures/doi/sdo/treatment_effect_sdo.png")
# 
# results <- df1 %>% 
#   rename(weights = ebal_w) %>% 
#   mutate(group = t_sdo) %>% 
#   filter(wave != 3) %>% 
#   drop_na(group) %>% 
#   gather(key = type, value = response, contains("gov")) %>% 
#   group_by(type, group) %>% 
#   nest() %>% 
#   mutate(result = data %>% 
#            purrr::map(~lm(response ~ as.factor(treatment)*time_start, weights = weights, data = .)),
#          data = data %>% 
#            purrr::map(sim_df),
#          pred = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,1]),
#          conf_low = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,2]),
#          conf_high = purrr::map2(result, data, ~predict(.x, newdata = .y, interval = "confidence")[,3]))
# 
# for (i in unique(results$type)) {
#   results %>% 
#     dplyr::select(-result) %>% 
#     unnest() %>% 
#     filter(type == i) %>% 
#     ggplot() + 
#     geom_line(aes(x = time_start, y = pred, group = as.factor(treatment))) + 
#     geom_ribbon(aes(x = time_start, ymin = conf_low, ymax = conf_high, group = as.factor(treatment)),
#                 alpha = 0.5) + 
#     geom_vline(aes(xintercept = ymd_hms("2018-12-28 18:00:00", tz = "Asia/Tokyo"))) + 
#     geom_rug(aes(x = time_start)) + 
#     facet_grid(~group, scale = "free_x") + 
#     labs(title = i)
#   ggsave(str_glue("figures/doi/sdo/{i}_sdo.png"))
# }

# temp <- df1 %>% 
#   filter(wave == 1)
# 
# model <- temp %>% 
#   lm(jpn_gov_3 ~ as.factor(treatment)*time_start*t_ideology + age + gender + as.factor(educ) + 
#        as.factor(job), data = .)
# 
# bind_rows(tibble(time_start = temp[temp$t_ideology == "Left",]$time_start,
#                  treatment = temp[temp$t_ideology == "Left",]$treatment,
#                  t_ideology = "Left",
#                  age = median(temp[temp$t_ideology == "Left",]$age, na.rm = TRUE),
#                  gender = median(temp[temp$t_ideology == "Left",]$gender, na.rm = TRUE),
#                  educ = median(temp[temp$t_ideology == "Left",]$educ, na.rm = TRUE),
#                  job = median(temp[temp$t_ideology == "Left",]$job, na.rm = TRUE)),
#           tibble(time_start = temp[temp$t_ideology == "Middle",]$time_start,
#                  treatment = temp[temp$t_ideology == "Middle",]$treatment,
#                  t_ideology = "Middle",
#                  age = median(temp[temp$t_ideology == "Middle",]$age, na.rm = TRUE),
#                  gender = median(temp[temp$t_ideology == "Middle",]$gender, na.rm = TRUE),
#                  educ = median(temp[temp$t_ideology == "Middle",]$educ, na.rm = TRUE),
#                  job = median(temp[temp$t_ideology == "Middle",]$job, na.rm = TRUE)),
#           tibble(time_start = temp[temp$t_ideology == "Right",]$time_start,
#                  treatment = temp[temp$t_ideology == "Right",]$treatment,
#                  t_ideology = "Right",
#                  age = median(temp[temp$t_ideology == "Right",]$age, na.rm = TRUE),
#                  gender = median(temp[temp$t_ideology == "Right",]$gender, na.rm = TRUE),
#                  educ = median(temp[temp$t_ideology == "Right",]$educ, na.rm = TRUE),
#                  job = median(temp[temp$t_ideology == "Right",]$job, na.rm = TRUE))) %>% 
#   mutate(pred = predict(model, ., interval = "confidence")[,1],
#          conf_low = predict(model, ., interval = "confidence")[,2],
#          conf_high = predict(model, ., interval = "confidence")[,3]) %>% 
#   ggplot() + 
#   geom_line(aes(x = time_start, y = pred, group = as.factor(treatment))) + 
#   geom_ribbon(aes(x = time_start, ymin = conf_low, ymax = conf_high, group = as.factor(treatment)), 
#               alpha = 0.3) + 
#   geom_vline(aes(xintercept = ymd_hms("2018-12-28 18:00:00", tz = "Asia/Tokyo")), linetype = 2) + 
#   geom_rug(aes(x = time_start)) + 
#   facet_grid(~ t_ideology) + 
#   scale_y_continuous(breaks = c(2,3)) + 
#   labs(x = "", y = "predicted value")
# ggsave("figures/doi/blog/plot_for_blog1.png")
# 
# temp %>% 
#   filter(!is.na(t_ideology)) %>% 
#   ggplot() + 
#   geom_smooth(aes(x = time_start, y = jpn_gov_3, colour = t_ideology)) + 
#   geom_rug(aes(x = time_start)) + 
#   geom_vline(aes(xintercept = ymd_hms("2018-12-28 18:00:00", tz = "Asia/Tokyo")), linetype = 2) + 
#   labs(x = "", y = "predicted value", colour = "Ideology") + 
#   scale_y_continuous(breaks = c(2,3)) + 
#   theme(legend.position = "bottom")
# ggsave("figures/doi/blog/plot_for_blog2.png")

# causal forest -----------------------------------------------------------


# library(grf)
# 
# df2 <- df1 %>%
#   filter(wave != 3) %>%
#   dplyr::select(contains("gov"), treatment = wave, age, gender, educ,
#          ideology, sdo, critical) %>%
#   drop_na()
# 
# X <- df2 %>%
#   model.matrix(~ age + gender + educ + ideology + sdo + critical - 1, data = .)
# 
# Y = df2 %>%
#   pull(jpn_gov_5)
# 
# W <- df2 %>%
#   pull(treatment)
# 
# tau.forest = causal_forest(X, Y, W, num.trees = 4000)
# 
# X.test <- tibble(age = median(df2$age, na.rm = TRUE),
#                  gender = median(df2$gender, na.rm = TRUE),
#                  educ = median(df2$educ, na.rm = TRUE),
#                  ideology = 1:11,
#                  sdo = median(df2$sdo, na.rm = TRUE),
#                  critical = median(df2$critical, na.rm = TRUE)) %>%
#   model.matrix(~ age + gender + educ + ideology + sdo + critical - 1, data = .)
# 
# tau.hat = predict(tau.forest, X.test, estimate.variance = TRUE)
# sigma.hat = sqrt(tau.hat$variance.estimates)
# 
# tibble(med = X.test[,4],
#        pred = tau.hat$predictions,
#        conf_low = tau.hat$predictions - 1.96 * sigma.hat,
#        conf_high = tau.hat$predictions + 1.96 * sigma.hat) %>%
#   ggplot() +
#   geom_line(aes(x = med, y = pred)) +
#   geom_ribbon(aes(x = med, ymin = conf_low, ymax = conf_high), alpha = 0.5) +
#   geom_hline(aes(yintercept = 0), linetype = 2)
# 
# df3 <- df1 %>%
#   filter(wave == 1) %>%
#   dplyr::select(contains("gov"), time_start, age, gender, educ,
#          ideology, sdo, critical) %>%
#   mutate(time_start = difftime(time_start, ymd_hms("2018-12-28 18:00:00", tz = "Asia/Tokyo"),
#                                units = "days") %>%
#            as.numeric()) %>%
#   drop_na()
# 
# X <- df3 %>%
#   model.matrix(~ time_start + age + gender + educ + ideology + sdo + critical - 1, data = .)
# 
# Y = df3 %>%
#   pull(rok_gov_2)
# 
# reg.forest <- regression_forest(X, Y, num.trees = 4000)
# 
# X.test <- tibble(time_start = df3$time_start,
#                  age = median(df2$age, na.rm = TRUE),
#                  gender = median(df2$gender, na.rm = TRUE),
#                  educ = median(df2$educ, na.rm = TRUE),
#                  ideology = median(df2$ideology, na.rm = TRUE),
#                  sdo = median(df2$sdo, na.rm = TRUE),
#                  critical = median(df2$critical, na.rm = TRUE)) %>%
#   model.matrix(~ time_start + age + gender + educ + ideology + sdo + critical - 1, data = .)
# 
# reg.hat = predict(reg.forest, X.test, estimate.variance = TRUE)
# sigma.hat = sqrt(reg.hat$variance.estimates)
# 
# tibble(med = X.test[,1],
#        pred = tau.hat$predictions,
#        conf_low = tau.hat$predictions - 1.96 * sigma.hat,
#        conf_high = tau.hat$predictions + 1.96 * sigma.hat) %>%
#   ggplot() +
#   geom_line(aes(x = med, y = pred)) +
#   geom_ribbon(aes(x = med, ymin = conf_low, ymax = conf_high), alpha = 0.5)

# text analysis -----------------------------------------------------------

# library(quanteda)
# library(wordcloud2)
# 
# df4 <- df %>%
#   filter(!is.na(text))
# 
# corp <- df4 %>%
#   corpus(text_field = "text")
# 
# toks <- tokens(corp)
# 
# dfm <- toks %>%
#   dfm() %>%
#   dfm_remove("^[ぁ-んー]+$", valuetype = "regex", min_nchar = 2) %>%
#   dfm_remove("^[一-龠][ぁ-ん]", valuetype = "regex")
# 
# textstat_frequency(dfm)
# 
# group <- "gender"
# 
# dfm %>%
#   dfm_subset(!is.na(docvars(., group))) %>%
#   dfm_group(groups = group) %>%
#   textplot_wordcloud(comparison = TRUE, max_words = 150, min_size = 1,
#                      rotation = 0, adjust = -0.25)
# 
# group <- "gender"
# 
# textstat_keyness(dfm,
#                  docvars(dfm, group) == 1 & !is.na(docvars(dfm, group))) %>%
#   filter(p < 0.1)
# 
# kwic(toks, "日本")


# geo analysis ------------------------------------------------------------


# map_data("world") %>% 
#   rename(lon = long) %>% 
#   ggplot(aes(x = lon, y = lat)) +
#   geom_polygon(aes(group = group), fill = "lightgray") + 
#   geom_point(data = df1) + 
#   facet_wrap(~treatment)
# ggsave("figures/location_distribution.png")

# RDD analysis ------------------------------------------------------------

RDestimate(policy_4 ~ time, 
           data = df %>% 
             filter(wave == 1),
           kernel = "rectangular") %>% 
  summary()