# packages ----------------------------------------------------------------

library(tidyverse)
library(readxl)
library(lubridate)
library(sf)
library(pforeach)

# functions ---------------------------------------------------------------

replace_name <- function(data, pattern, replacement) {
  names(data) <- names(data) %>% 
    str_replace(pattern, str_c(replacement, "_"))
  return(data)
}

# name of variables -------------------------------------------------------

# read_csv("data/2018年12月調査　データ.csv") %>%
#   slice(1) %>%
#   write_csv("data/var_list/dec1.csv")
# 
# read_csv("data/2019年1月調査　データ.csv",
#          locale = locale(encoding = "shift-jis")) %>%
#   slice(1) %>%
#   write_csv("data/var_list/jan1.csv")
# 
# read_xlsx("data/2019年3月調査　データ.xlsx", sheet = 1) %>%
#   select(var = "列名", item = "質問文", category = "カテゴリラベル") %>% 
#   distinct(var, .keep_all = TRUE) %>% 
#   drop_na(category) %>% 
#   fill(item) %>% 
#   mutate(item = if_else(str_detect(var, "[_]"), str_c(item, category, sep = "_"), item),
#          var = fct_inorder(var)) %>% 
#   select(-category) %>% 
#   spread(key = var, value = item) %>% 
#   write_csv("data/var_list/mar1.csv")

# list of variable names, question IDs and items --------------------------

left_join(read_csv("data/var_list/dec1.csv") %>%
            slice(1) %>%
            gather(key = var_dec, value = item_dec),
          read_csv("data/var_list/dec1.csv") %>%
            slice(2) %>%
            gather(key = var_dec, value = var_name),
          by = "var_dec") %>%
  drop_na() %>%
  select(var_name, var_dec, item_dec) %>%
  write_csv("data/var_list/dec2.csv")

left_join(read_csv("data/var_list/jan1.csv") %>%
            slice(1) %>%
            gather(key = var_jan, value = item_jan),
          read_csv("data/var_list/jan1.csv") %>%
            slice(2) %>%
            gather(key = var_jan, value = var_name),
          by = "var_jan") %>%
  drop_na() %>%
  select(var_name, var_jan, item_jan) %>%
  write_csv("data/var_list/jan2.csv")

left_join(read_csv("data/var_list/mar1.csv") %>%
            slice(1) %>%
            gather(key = var_mar, value = item_mar),
          read_csv("data/var_list/mar1.csv") %>%
            slice(2) %>%
            gather(key = var_mar, value = var_name),
          by = "var_mar") %>%
  drop_na() %>%
  select(var_name, var_mar, item_mar) %>%
  write_csv("data/var_list/mar2.csv")

# renaming ----------------------------------------------------------------

read_csv("data/2018年12月調査　データ.csv") %>%
  slice(1) %>%
  rename(Q12_12 = Q12_11, 
         Q14_10 = Q14_9, 
         Q16_22 = Q16_20) %>% 
  select(id = V1,
         time_start = V8,
         time_end = V9,
         agree = Q1,
         use_of_force = Q3,
         hawk_dove = Q4,
         tv_news = Q5,
         np_news = Q6,
         know_event = Q19,
         ideology = Q26,
         party = Q27,
         age = Q28_65,
         gender = Q29,
         educ = Q30,
         job = Q31,
         work_hour = Q32,
         lat = LocationLatitude,
         lon = LocationLongitude,
         matches("(Q2|Q7_|Q8_|Q10_|Q12_|Q14_|Q16_|Q17_|Q20_|Q21_|Q22_|Q23_|Q24_|Q25_)")) %>%
  replace_name("Q2_", "friendship") %>%
  replace_name("Q7_", "web_news") %>%
  replace_name("Q8_", "np") %>%
  replace_name("Q10_", "tv_A") %>%
  replace_name("Q12_", "tv_B") %>%
  replace_name("Q14_", "tv_C") %>%
  replace_name("Q16_", "tv_D") %>%
  replace_name("Q17_", "web") %>%
  replace_name("Q20_", "fact") %>%
  replace_name("Q21_", "jpn_gov") %>%
  replace_name("Q22_", "rok_gov") %>%
  replace_name("Q23_", "policy") %>%
  replace_name("Q24_", "critical") %>%
  replace_name("Q25_", "sdo") %>%
  gather(key = var_name, value = item_dec, factor_key = TRUE) %>%
  full_join(read_csv("data/var_list/dec2.csv") %>%
               select(-var_name),
            by = "item_dec") %>%
  write_csv("data/var_list/dec3.csv")

read_csv("data/2019年1月調査　データ.csv",
         locale = locale(encoding = "shift-jis")) %>%
  slice(1) %>%
  select(id = V1,
         time_start = V8,
         time_end = V9,
         agree = Q1,
         use_of_force = Q3,
         hawk_dove = Q4,
         tv_news = Q5,
         np_news = Q6,
         treatment = Q11,
         know_event = Q13,
         apology_colony = Q18,
         apology_comfort = Q19,
         apology_genocide = Q20,
         apology_general = Q21,
         ideology = Q24,
         age = Q25_65,
         gender = Q26,
         educ = Q27,
         lat = LocationLatitude,
         lon = LocationLongitude,
         matches("(Q2_|Q7_|Q8_|Q14_|Q15_|Q16_|Q17_|Q22_|Q23_)")) %>%
  replace_name("Q2_", "friendship") %>%
  replace_name("Q7_", "web_news") %>%
  replace_name("Q8_", "np") %>%
  replace_name("Q14_", "fact") %>%
  replace_name("Q15_", "jpn_gov") %>%
  replace_name("Q16_", "rok_gov") %>%
  replace_name("Q17_", "policy") %>%
  replace_name("Q22_", "critical") %>%
  replace_name("Q23_", "sdo") %>%
  gather(key = var_name, value = item_jan, factor_key = TRUE) %>%
  full_join(read_csv("data/var_list/jan2.csv") %>%
               select(-var_name),
            by = "item_jan") %>%
  write_csv("data/var_list/jan3.csv")

read_xlsx("data/2019年3月調査　データ.xlsx", sheet = 2) %>%
  rbind(names(.), .) %>%
  slice(1) %>%
  rename(q10_05 = q10_04, 
         q10_06 = q10_05, 
         q10_07 = q10_06, 
         q10_08 = q10_07, 
         q10_09 = q10_08, 
         q10_11 = q10_09, 
         q10_12 = q10_10, 
         q10_13 = q10_11, 
         q10_14 = q10_12, 
         q10_15 = q10_13, 
         q10_16 = q10_14, 
         q10_20 = q10_15, 
         q10_17 = q10_16, 
         q10_18 = q10_17, 
         q10_19 = q10_18, 
         q10_21 = q10_19, 
         q10_22 = q10_20) %>% 
  select(id = record_id,
         agree = s00,
         age = s01,
         gender = s02,
         location = s03,
         use_of_force = q01,
         hawk_dove = q02,
         np_news = q04,
         status = q16,
         apology_colony = q17,
         apology_comfort = q18,
         apology_genocide = q19,
         apology_general = q20,
         ideology = q32,
         educ = q33,
         treatment = pat,
         matches("(q03_|q05_|q06_|q07_|q08_|q09_|q10_|q11_|q12_|q13_|q14_|q15_|q21_)[0-9]+$")) %>%
  replace_name("q03_", "tv_news") %>%
  replace_name("q05_", "web_news") %>%
  replace_name("q06_", "np") %>%
  replace_name("q07_", "tv_A") %>%
  replace_name("q08_", "tv_B") %>%
  replace_name("q09_", "tv_C") %>%
  replace_name("q10_", "tv_D") %>%
  replace_name("q11_", "responsibility") %>%
  replace_name("q12_", "fact") %>%
  replace_name("q13_", "jpn_gov") %>%
  replace_name("q14_", "rok_gov") %>%
  replace_name("q15_", "policy") %>%
  replace_name("q21_", "sdo") %>%
  gather(key = var_name, value = var_mar, factor_key = TRUE) %>%
  mutate(var_name = var_name %>%
           str_replace("_0", "_")) %>%
  full_join(read_csv("data/var_list/mar2.csv") %>%
              select(-var_name),
            by = "var_mar") %>%
  select(var_name, item_mar, var_mar) %>%
  write_csv("data/var_list/mar3.csv")

temp <- read_csv("data/var_list/dec3.csv") %>%
  full_join(read_csv("data/var_list/jan3.csv"),
            by = "var_name") %>%
  full_join(read_csv("data/var_list/mar3.csv"),
            by = "var_name")

full_join(temp %>%
            select(var_name, contains("var")) %>%
            gather(key = type, value = var, -var_name) %>%
            mutate(type = type %>%
                     str_remove("var_")),
          temp %>%
            select(var_name, contains("item")) %>%
            gather(key = type, value = item, -var_name) %>%
            mutate(type = type %>%
                     str_remove("item_"))) %>%
  arrange(var_name) %>%
  write_excel_csv("data/var_list.csv")

# selecting and renaming variables ----------------------------------------

read_csv("data/2018年12月調査　データ.csv") %>% 
  slice(-1) %>% 
  rename(Q12_12 = Q12_11, 
         Q14_10 = Q14_9, 
         Q16_22 = Q16_20) %>% 
  select(time_start = V8,
         time_end = V9,
         agree = Q1,
         use_of_force = Q3,
         hawk_dove = Q4,
         tv_news = Q5,
         np_news = Q6,
         know_event = Q19,
         ideology = Q26,
         party = Q27,
         age = Q28_65,
         gender = Q29,
         educ = Q30,
         job = Q31,
         work_hour = Q32,
         lat = LocationLatitude,
         lon = LocationLongitude,
         text = Q33,
         matches("(Q2|Q7_|Q8_|Q10_|Q12_|Q14_|Q16_|Q17_|Q20_|Q21_|Q22_|Q23_|Q24_|Q25_)")) %>%
  replace_name("Q2_", "friendship") %>%
  replace_name("Q7_", "web_news") %>%
  replace_name("Q8_", "np") %>%
  replace_name("Q10_", "tv_A") %>%
  replace_name("Q12_", "tv_B") %>%
  replace_name("Q14_", "tv_C") %>%
  replace_name("Q16_", "tv_D") %>%
  replace_name("Q17_", "web") %>%
  replace_name("Q20_", "fact") %>%
  replace_name("Q21_", "jpn_gov") %>%
  replace_name("Q22_", "rok_gov") %>%
  replace_name("Q23_", "policy") %>%
  replace_name("Q24_", "critical") %>%
  replace_name("Q25_", "sdo") %>%
  mutate_at(vars(contains("time")), ymd_hms) %>%
  write_excel_csv("data/data_dec.csv")

read_csv("data/2019年1月調査　データ.csv",
         locale = locale(encoding = "shift-jis")) %>% 
  slice(-1) %>%
  select(time_start = V8,
         time_end = V9,
         agree = Q1,
         use_of_force = Q3,
         hawk_dove = Q4,
         tv_news = Q5,
         np_news = Q6,
         treatment = Q11,
         know_event = Q13,
         apology_colony = Q18,
         apology_comfort = Q19,
         apology_genocide = Q20,
         apology_general = Q21,
         ideology = Q24,
         age = Q25_65,
         gender = Q26,
         educ = Q27,
         lat = LocationLatitude,
         lon = LocationLongitude,
         matches("(Q2_|Q7_|Q8_|Q14_|Q15_|Q16_|Q17_|Q22_|Q23_)")) %>%
  replace_name("Q2_", "friendship") %>%
  replace_name("Q7_", "web_news") %>%
  replace_name("Q8_", "np") %>%
  replace_name("Q14_", "fact") %>%
  replace_name("Q15_", "jpn_gov") %>%
  replace_name("Q16_", "rok_gov") %>%
  replace_name("Q17_", "policy") %>%
  replace_name("Q22_", "critical") %>%
  replace_name("Q23_", "sdo") %>%
  mutate_at(vars(contains("time")), ymd_hm) %>%
  write_excel_csv("data/data_jan.csv")

read_xlsx("data/2019年3月調査　データ.xlsx", sheet = 2) %>% 
  rename(q10_05 = q10_04, 
         q10_06 = q10_05, 
         q10_07 = q10_06, 
         q10_08 = q10_07, 
         q10_09 = q10_08, 
         q10_11 = q10_09, 
         q10_12 = q10_10, 
         q10_13 = q10_11, 
         q10_14 = q10_12, 
         q10_15 = q10_13, 
         q10_16 = q10_14, 
         q10_20 = q10_15, 
         q10_17 = q10_16, 
         q10_18 = q10_17, 
         q10_19 = q10_18, 
         q10_21 = q10_19, 
         q10_22 = q10_20) %>% 
  select(agree = s00,
         age = s01,
         gender = s02,
         region = s03,
         use_of_force = q01,
         hawk_dove = q02,
         np_news = q04,
         status = q16,
         apology_colony = q17,
         apology_comfort = q18,
         apology_genocide = q19,
         apology_general = q20,
         ideology = q32,
         educ = q33,
         treatment = pat,
         matches("(q03_|q05_|q06_|q07_|q08_|q09_|q10_|q11_|q12_|q13_|q14_|q15_|q21_)[0-9]+$")) %>%
  replace_name("q03_", "tv_news") %>%
  replace_name("q05_", "web_news") %>%
  replace_name("q06_", "np") %>%
  replace_name("q07_", "tv_A") %>%
  replace_name("q08_", "tv_B") %>%
  replace_name("q09_", "tv_C") %>%
  replace_name("q10_", "tv_D") %>%
  replace_name("q11_", "responsibility") %>%
  replace_name("q12_", "fact") %>%
  replace_name("q13_", "jpn_gov") %>%
  replace_name("q14_", "rok_gov") %>%
  replace_name("q15_", "policy") %>%
  replace_name("q21_", "sdo") %>%
  replace_name("_0", "") %>%
  mutate(ideology = parse_number(ideology)) %>%
  write_excel_csv("data/data_mar.csv")

# finding prefecture ----------------------------------------------------------


japan <- st_read("data/japan_map/N03-19_190101.shp")

find_prefec <- function(japan, point) {
  
  if (sum(is.na(point)) > 0) {
    return("不明")
  }
  
  which.row <- st_contains(japan, st_point(point), sparse = FALSE) %>%  
    grep(TRUE, .)
  
  if (identical(which.row, integer(0)) == TRUE) {
    return("国外")
  } else {
    japan[which.row, ]$N03_001 %>% 
      return()
  }
}

dec <- read_csv("data/data_dec.csv") %>%
  mutate(wave = 1,
         age = 73 - age,
         gender = case_when(gender == 0 ~ 0,
                            gender == 1 ~ 1,
                            gender == 3 ~ 2,
                            TRUE ~ gender),
         educ = if_else(educ == 10, 7, educ))

dec <- pforeach(row = rows(dec), .c = rbind)({
  row %>% 
    mutate(prefecture = find_prefec(japan, c(lon, lat)))
}) %>% 
  left_join(jpndistrict::jpnprefs %>% 
              select(prefecture, region), 
            by = "prefecture") %>% 
  mutate(region = case_when(prefecture %in% c("北海道", "青森県", "岩手県", "宮城県", "秋田県", "山形県", "福島県") ~ 1,
                            prefecture %in% c("茨城県", "栃木県", "群馬県", "埼玉県", "千葉県", "東京都", "神奈川県") ~ 2,
                            prefecture %in% c("新潟県", "富山県", "石川県", "福井県", "山梨県", "長野県", "岐阜県", "静岡県", "愛知県", "三重県") ~ 3,
                            prefecture %in% c("滋賀県", "京都府", "大阪府", "兵庫県", "奈良県", "和歌山県") ~ 4,
                            prefecture %in% c("鳥取県", "島根県", "岡山県", "広島県", "山口県", "徳島県", "香川県", "愛媛県", "高知県") ~ 5,
                            prefecture %in% c("福岡県", "佐賀県", "長崎県", "熊本県", "大分県", "宮崎県", "鹿児島県", "沖縄県") ~ 6,
                            TRUE ~ NA_real_))

jan <- read_csv("data/data_jan.csv") %>%
  mutate(wave = 2,
         age = 73 - age,
         gender = case_when(gender == 2 ~ 0,
                            gender == 1 ~ 1,
                            gender == 3 ~ 2,
                            TRUE ~ gender))

jan <- pforeach(row = rows(jan), .c = rbind)({
  row %>% 
    mutate(prefecture = find_prefec(japan, c(lon, lat)))
}) %>% 
  left_join(jpndistrict::jpnprefs %>% 
              select(prefecture, region), 
            by = "prefecture") %>% 
  mutate(region = case_when(prefecture %in% c("北海道", "青森県", "岩手県", "宮城県", "秋田県", "山形県", "福島県") ~ 1,
                            prefecture %in% c("茨城県", "栃木県", "群馬県", "埼玉県", "千葉県", "東京都", "神奈川県") ~ 2,
                            prefecture %in% c("新潟県", "富山県", "石川県", "福井県", "山梨県", "長野県", "岐阜県", "静岡県", "愛知県", "三重県") ~ 3,
                            prefecture %in% c("滋賀県", "京都府", "大阪府", "兵庫県", "奈良県", "和歌山県") ~ 4,
                            prefecture %in% c("鳥取県", "島根県", "岡山県", "広島県", "山口県", "徳島県", "香川県", "愛媛県", "高知県") ~ 5,
                            prefecture %in% c("福岡県", "佐賀県", "長崎県", "熊本県", "大分県", "宮崎県", "鹿児島県", "沖縄県") ~ 6,
                            TRUE ~ NA_real_))

mar <- read_csv("data/data_mar.csv") %>% 
  mutate(wave = 3,
         age = 2019 - age,
         gender = case_when(gender == 2 ~ 0,
                            gender == 1 ~ 1,
                            gender == 3 ~ 2,
                            TRUE ~ gender))

# combining data ----------------------------------------------------------

bind_rows(dec, jan, mar) %>% 
  select(wave, time_start, time_end, treatment, agree, age, gender, educ, job, work_hour, lat, lon, region, prefecture, 
         ideology, party, use_of_force, hawk_dove, contains("friendship"), contains("sdo"), contains("critical"), 
         contains("apology"), know_event, contains("fact"), contains("jpn_gov"), contains("rok_gov"), contains("policy"), 
         contains("responsibility"), status, contains("np"), contains("tv_news"), contains("tv_A"),  contains("tv_B"),
         contains("tv_C"), contains("tv_D"), contains("web"), text) %>% 
  write_excel_csv("data/data_combined.csv")
