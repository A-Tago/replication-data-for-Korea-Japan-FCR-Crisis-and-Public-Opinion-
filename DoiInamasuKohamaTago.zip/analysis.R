library(tidyverse)
library(lubridate)
library(BalanceR)
library(fastDummies)
library(CBPS)
library(broom)
library(purrr)

theme_set(
  theme_minimal(base_family = "Noto Sans CJK JP Light") + 
    theme(legend.position = "bottom")
)

cutoff <- "2018-12-28 18:00:00"

df <- read_csv("data.csv", guess_max = 6000) %>% 
  mutate_at(vars(matches("(jpn|rok|policy)")), na_if, 6) %>% 
  mutate_at(vars(matches("(np_[0-9]+|tv_[ABCD]_[0-9]+|web_[0-9]+)")), replace_na, 0) %>% 
  mutate_at(vars(contains("time")), ymd_hms, tz = "Asia/Tokyo") %>% 
  mutate(treatment = treatment %>% 
           replace_na(0),
         gender = gender %>% 
           na_if(2),
         ideology = ideology %>% 
           na_if(12),
         use_of_force = use_of_force %>% 
           na_if(5),
         hawk_dove = hawk_dove %>% 
           na_if(3),
         know_event = know_event %>% 
           na_if(3),
         party = party %>% 
           na_if(9),
         critical = (critical_1 - critical_2 + critical_3 + critical_4 + critical_6 - 
                       critical_7 + critical_8 + critical_9 + critical_10 + critical_11 + 
                       critical_12),
         sdo = sdo_1 + sdo_2 + sdo_3 + sdo_4 + sdo_5 + sdo_6 + sdo_7 + sdo_8 + (7 - sdo_9) + 
           (7 - sdo_10) + (7 - sdo_11) + (7 - sdo_12) + (7 - sdo_13) + (7 - sdo_14) + (7 - sdo_15) + 
           (7 - sdo_16),
         t_ideology = case_when(ideology < 6 ~ 0,
                                ideology == 6 ~ 1,
                                ideology > 6 ~ 2,
                                ideology == 12 ~ NA_real_),
         t_sdo = case_when(sdo < quantile(sdo, 1/3, na.rm = TRUE) ~ 0,
                           sdo >= quantile(sdo, 1/3, na.rm = TRUE) & 
                             sdo <= quantile(sdo, 2/3, na.rm = TRUE) ~ 1,
                           sdo > quantile(sdo, 2/3, na.rm = TRUE) ~ 2,
                           TRUE ~ NA_real_),
         treatment = case_when(wave == 1 & time_start < ymd_hms(cutoff, tz = "Asia/Tokyo") ~ 0,
                               wave == 1 & time_start > ymd_hms(cutoff, tz = "Asia/Tokyo") ~ 1,
                               TRUE ~ treatment),
         time = interval(ymd_hms(cutoff, tz = "Asia/Tokyo"), time_start) %>% 
           time_length(unit = "day"),
         jpn_gov_3 = if_else(wave != 1, 6 - jpn_gov_3, jpn_gov_3),
         rok_gov_3 = if_else(wave != 1, 6 - rok_gov_3, rok_gov_3)) %>% 
  filter(agree == 1)

df1 <- df %>% 
  drop_na(gender, age, educ, region, ideology, sdo) %>% 
  filter((wave == 1 & date(time_start) > "2018-12-26" & date(time_start) < "2018-12-30") | 
           (wave == 2 & date(time_start) > "2019-01-15") | 
           wave == 3) %>% 
  filter(between(age, 20, 69)) %>% 
  mutate(treatment = case_when(wave == 1 & treatment == 0 ~ 0,
                               wave == 1 & treatment == 1 ~ 1,
                               wave == 2 ~ 2,
                               wave == 3 ~ 3),
         generation = age %/% 10 * 10)

df1 %>% 
  drop_na(wave, age, gender, educ, region, ideology, sdo) %>% 
  dummy_cols(c("educ", "region")) %>% 
  BalanceR(group = "wave", 
           cov = c("age", "gender", str_c("educ_", 1:7), str_c("region_", 1:6), "ideology", "sdo")) %>% 
  plot(color = FALSE) + 
  scale_y_discrete(label = c("SDO", "Ideology", "Kyushu/Okinawa", "Chugoku/Shikoku", 
                             "Kinki", "Chubu", "Kanto", "Hokkaido/Tohoku", "MA/Ph.D", 
                             "Graduate student", "College graduate", "College student", 
                             "High school graduate", "High school student", 
                             "Less than High school", "Gender", "Age")) + 
  theme_minimal(base_family = "Noto Sans CJK JP Light") + 
  theme(legend.position = "bottom")
# ggsave("figures/balance_covariates.png",
#        width = 9, height = 6, scale = 2/3)

fit <- CBPS(as.factor(treatment) ~ 
              gender + age + as.factor(educ) + as.factor(region) + as.factor(t_ideology) + as.factor(t_sdo), 
            data = df1)

df2 <- df1 %>% 
  mutate(weights = fit$weights)

df2 %>% 
  pivot_longer(contains("fact"), names_to = "type", values_to = "response") %>% 
  mutate(response = if_else(response == 3, 0, 1)) %>% 
  group_by(type) %>% 
  nest() %>% 
  mutate(result = purrr::map(data, 
                             ~lm(response ~ as.factor(treatment), weights = weights, data = .) %>% 
                               tidy(conf.int = TRUE))) %>% 
  unnest(result) %>% 
  filter(str_detect(term, "treatment")) %>% 
  mutate(type = type %>% 
           str_replace("f", "F") %>% 
           str_replace("_", " ") %>% 
           factor(levels = str_c("Fact ", 1:11)),
         term = term %>% 
           str_remove("as.factor[(]treatment[)]"),
         signif = if_else(p.value < 0.05, "<0.05", ">0.05")) %>% 
  ggplot() + 
  geom_pointrange(aes(x = as.factor(term), y = estimate, ymin = conf.low, ymax = conf.high, 
                      linetype = signif)) + 
  geom_hline(aes(yintercept = 0), alpha = 0.3) + 
  facet_wrap(~ type, scales = "free_y") + 
  theme(legend.position = "bottom") + 
  labs(x = "", y = "", linetype = "P-value")
# ggsave("figures/fact/treatment_fact_cbps.png",
#        width = 9, height = 6, scale = 2/3)

df2 %>% 
  pivot_longer(contains("gov"), names_to = "type", values_to = "response") %>% 
  group_by(type) %>% 
  nest() %>% 
  mutate(result = purrr::map(data, 
                             ~lm(response ~ as.factor(treatment), weights = weights, data = .) %>% 
                               tidy(conf.int = TRUE))) %>% 
  dplyr::select(type, result) %>% 
  unnest(result) %>% 
  filter(str_detect(term, "treatment")) %>% 
  mutate(type = type %>% 
           str_replace("_gov_", " ") %>% 
           str_to_upper(),
         term = term %>% 
           str_remove("as.factor[(]treatment[)]"),
         signif = if_else(p.value < 0.05, "<0.05", ">0.05")) %>% 
  ggplot() + 
  geom_pointrange(aes(x = as.factor(term), y = estimate, ymin = conf.low, ymax = conf.high, 
                      linetype = signif),
                  position = position_dodge(width = 0.5)) + 
  geom_hline(aes(yintercept = 0), alpha = 0.3) + 
  facet_wrap(~ type, scales = "free_y", nrow = 2) + 
  labs(x = "", y = "", linetype = "P-value")
# ggsave("figures/treatment_effects/treatment_effects_cbps.png",
#        width = 9, height = 6, scale = 2/3)

df2 %>% 
  pivot_longer(contains("policy"), names_to = "type", values_to = "response") %>% 
  mutate(response = if_else(response == 3, 0, 1)) %>% 
  group_by(type) %>% 
  nest() %>% 
  mutate(result = purrr::map(data, 
                             ~lm(response ~ as.factor(treatment), weights = weights, data = .) %>% 
                               tidy(conf.int = TRUE))) %>% 
  dplyr::select(type, result) %>% 
  unnest(result) %>% 
  filter(str_detect(term, "treatment")) %>% 
  mutate(type = type %>% 
           str_replace("p", "P") %>% 
           str_replace("_", " "),
         term = term %>% 
           str_remove("as.factor[(]treatment[)]"),
         signif = if_else(p.value < 0.05, "<0.05", ">0.05")) %>% 
  ggplot() + 
  geom_pointrange(aes(x = as.factor(term), y = estimate, ymin = conf.low, ymax = conf.high, 
                      linetype = signif),
                  position = position_dodge(width = 1)) + 
  geom_hline(aes(yintercept = 0), alpha = 0.3) + 
  facet_wrap(~ type, scales = "free_y") + 
  labs(x = "", y = "", linetype = "P-value")
# ggsave("figures/policy/treatment_policy_cbps.png",
#        width = 9, height = 6, scale = 2/3)
